# 智能传感教材确定性复现

需要Node.js 22+，无额外依赖。在解压目录运行：

```sh
node scripts/compute.mjs
node --test tests/models.test.mjs
```

原始题目数据来源见教材；低通阶跃、PCA点集和合法DS质量是作者构造，不代表真实设备实验。无随机抽样。
